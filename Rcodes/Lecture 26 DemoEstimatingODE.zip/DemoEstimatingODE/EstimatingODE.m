%% This is the demonstration of parameter cascading method for estimating parameters in ODE models - Written by Jiguo Cao

%% ODE models:  dx/dt = -theta*x

%% solve ODE 
thetaTru = 5; % ODE parameter
x0 = 10; % initial conditions
options = odeset('RelTol',1e-4,'AbsTol',[1e-4]);
tobs = linspace(0,1,21)';
[ttru,xtru] = ode45(@ode1,tobs,x0,options,thetaTru);

%% generate simulated data

nobs = length(tobs);
scale = 0.1;
noise = scale*randn(nobs,1);
yobs = xtru + noise;

h2 = figure(1);
plot(tobs,xtru,'k-','linewidth',2);
hold on
plot(tobs,yobs,'ko','linewidth',2);
xlabel('t','fontsize',15);
ylabel('ODE Solution','fontsize',15);
set(gca,'fontsize',15)
hold off

%% generate Basis functions
addpath('fdaM')
knots = linspace(0,1,21)';
norder   = 4;
nbasis   = length(knots) + norder - 2;
basis   = create_bspline_basis([0,1],nbasis,norder,knots);

% basis functions evaluated at tobs
Phimat   = eval_basis(tobs, basis);
% first derivative of basis functions evaluated at tobs
DPhimat  = eval_basis(tobs, basis, 1);
% second derivative of basis functions evaluated at tobs
D2Phimat = eval_basis(tobs, basis, 2);

% Calculate penalty term using Simpson's rule
quadts = linspace(0,1,101)';
nquad = length(quadts);
quadwts = ones(nquad,1);
quadwts(2:2:(nquad-1)) = 4;
quadwts(3:2:(nquad-2)) = 2;
h = quadts(2) - quadts(1);
quadwts = quadwts.*(h/3);

Qbasismat = eval_basis(quadts, basis);
DQbasismat = eval_basis(quadts, basis, 1);
D2Qbasismat = eval_basis(quadts, basis, 2);
Rmat = D2Qbasismat'*(D2Qbasismat.*(quadwts*ones(1,nbasis)));

%% Get initial value for the basis coefficients using penalized spline smoothing, in which the roughness penalty is defined using the second derivative

lambda = 1e-6;
chat = (Phimat'*Phimat+lambda.*Rmat)\(Phimat'*yobs);
xhat = Phimat*chat;

figure(2)
plot(tobs,xtru,'k-','linewidth',2);
hold on
plot(tobs,yobs,'ko','linewidth',2);
plot(tobs,xhat,'r-','linewidth',2)
xlabel('t','fontsize',15);
ylabel('ODE Solution','fontsize',15);
set(gca,'fontsize',15)
hold off

%% Update initial value for the basis coefficients using penalized spline smoothing, in which the roughness penalty is defined using the ODE model

input.Phimat = Phimat;
input.lambda = 1e5;
input.Qbasismat = Qbasismat;
input.DQbasismat = DQbasismat;
input.quadts = quadts;
input.quadwts = quadwts;
input.basis = basis;
input.yobs = yobs;

tolval  = 1e-10;
options1 = optimset( 'Display','iter', ...
    'DerivativeCheck','off', ...
    'MaxIter', 100, ...
    'GradObj','off', ...
    'TolCon', tolval, 'TolFun', tolval, ...
    'TolX',   tolval, 'TolPCG', tolval);
coef0 = chat; % Set initial value for the basis coefficients 
theta0 = 4;  % initial value of the ODE parameter
coef1 = lsqnonlin(@InnerOpt,coef0,[],[],options1,theta0,input);
[coef0,coef1]
%% Parameter Cascading Method for ODE parameter estimation

input.coef0 = coef1; % Update initial value for the basis coefficients 

thetaHat = lsqnonlin(@OutOpt,theta0,[],[],options1,input);

[theta0,thetaHat]
