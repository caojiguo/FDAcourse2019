function [Innerval,resid] = InnerOpt(coef,theta,input);

yobs = input.yobs;
Phimat = input.Phimat;
lambda = input.lambda;
Qbasismat = input.Qbasismat;
DQbasismat = input.DQbasismat;
quadwts = input.quadwts;

xhat = Phimat*coef;
resid = yobs-xhat;

DxQ = DQbasismat*coef;
xQ = Qbasismat*coef;

% evaluate Lx(t) at the quadrature points
resid2 = DxQ + theta.*xQ; %Lx(t)

Innerval = [resid;resid2.*sqrt(quadwts.*lambda)];
