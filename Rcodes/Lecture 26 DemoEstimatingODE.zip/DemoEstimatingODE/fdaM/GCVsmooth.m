function [Z2Fd,lambdaB1] = GCVsmooth(tobs,yobs,basis,l,r)

Lfd      = int2Lfd(2);
nlambda = 100;
lnlambda = linspace(l,r,nlambda);
GCVvec = zeros(nlambda,1);
for i=1:nlambda
    lambdaB1 = 10.^(lnlambda(i));
    inputfdPar = fdPar(basis, Lfd, lambdaB1);
    [Z2Fd,df,GCVvec(i)] = smooth_basis(tobs, yobs, inputfdPar);
end
plot(lnlambda,GCVvec,'k-')
xlabel('log(\lambda)')
ylabel('GCV')

[temp1,temp2] = min(GCVvec);
display(['log of optimal lambda is: ',num2str(lnlambda(temp2))])
lambdaB1 = 10.^(lnlambda(temp2));
inputfdPar = fdPar(basis, Lfd, lambdaB1);
[Z2Fd,df,GCVvec(i)] = smooth_basis(tobs, yobs, inputfdPar);
