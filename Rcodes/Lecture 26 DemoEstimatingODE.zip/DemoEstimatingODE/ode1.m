function dx = ode1(t,x,theta)
dx = -theta*x;
